hello, if u are a new user, thanks for getting injware <3 
stay updated in our discord, discord.gg/injware
if u have any questions or something, open a ticket.

ENJOY!